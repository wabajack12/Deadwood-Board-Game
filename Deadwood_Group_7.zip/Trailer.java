/*
 *Trailer is the subclas for the sage class where all the actors start.
 */
public class Trailer extends StageBase{

  public Trailer(String name, int[] area){
    super(name, area);

  }

  public int[] getArea(){
    return super.getArea();
  }
}
