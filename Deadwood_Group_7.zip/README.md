Owen Sheets, Tsuyoshi Baker, Ryan Haight

Our version of DeadWood kicks butt. We feel like we did a great job. We fixed all of the game errors in the terminal version and to our knowledge, have no remaining bugs in the game.

The visual appear in their own window, you interact with the game via buttons on the right hand side. They all work and to cancel one buttons action, press cancel.

One thing we would differently is add a interactions terminal in the game window to print informative messages. Like when you try to take a role that you are not a high enough level
for etc... We did not think it was worth it because anyone playing the game, knows the game. I.E. it isn't very fun.
