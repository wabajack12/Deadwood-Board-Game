import java.util.*;
import java.io.*;

public class DeadWood{

  public static void main(String[] args) throws FileNotFoundException{

    TheGame gameInstance = new TheGame();
    gameInstance.initGame();
    gameInstance.runGame();


  }
}
